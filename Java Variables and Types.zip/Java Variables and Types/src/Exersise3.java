
public class Exersise3 {

	public static void main(String[] args) {
		int x = 4;
		double value = 3 * x * x - 8 * x + 4;
		System.out.println(value);
	}

}
